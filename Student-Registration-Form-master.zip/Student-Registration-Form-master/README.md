

Below Image show how Event Handeling work with firstName inputfield


![Screenshot (132)_LI](https://user-images.githubusercontent.com/66914300/122548911-8eb2ac00-d04f-11eb-963c-283f71d69114.jpg)



Final Output

![Screenshot (132)](https://user-images.githubusercontent.com/66914300/122547802-2fa06780-d04e-11eb-83f1-9e435be14161.png)


![Screenshot (134)](https://user-images.githubusercontent.com/66914300/122548153-9aea3980-d04e-11eb-9c0c-f895c2b98e45.png)




This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.


You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

