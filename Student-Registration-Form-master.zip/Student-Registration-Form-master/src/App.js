
import './App.css';
import StudentComponent from './StudentComponent';

function App() {
  return (
    <div >
    <StudentComponent/>
    </div>
  );
}

export default App;
